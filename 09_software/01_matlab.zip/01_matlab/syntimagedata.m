%% clear P, Pmax
clear('P','Pmap', 'i', 'k', ...
    'lh', 'lpos', 'X', 'Y',...
    'file' );

k = 50;
i = 0;
lpos = [ 0 0 0 ];
xlab = 'Width'; ylab = 'Height'; zlab = 'Grayscale';
tit ='Heightmap';
Y = 0;
X = 0;
% file = 'heightmap.png';
file = 'finalMerge_16.bmp';

%% lese Bilddatei
[P, Pmap] = imread(file);
[X Y] = size(P);
% P = minus(P, 50);

%%
createfigure( double(P), 0, 0, 100 );

% title( tit )
% xlabel( xlab ), ylabel( ylab ), zlabel( zlab )
yLim([0 Y]); xLim([0 X]);zLim([-10 100]);

%% erstelle Surf- Plot; gray Colormap
fig_h= figure( 'Name','Heightmap Visualization', ...
            'NumberTitle','off');
% fig_h = vr.figure( world, 'Antialiasing', 'on' );
set(fig_h, 'WindowStyle', 'docked' );

% surf( double( P ) );
surf( double( BW ) );

colormap( gray );
% title( tit )
% xlabel( xlab ), ylabel( ylab ), zlabel( zlab )
yLim([0 Y]); xLim([0 X]);zLim([-10 500]);

set(findobj(gca,'type','surface'),...
    'FaceLighting','phong',...
    'EdgeLighting', 'none',...
    'AmbientStrength',0.1,'DiffuseStrength',0,...
    'SpecularStrength',10,'SpecularExponent',.8,...
    'BackFaceLighting','unlit');
%% FaceColor
set(findobj(gca,'type','surface'),'FaceColor', [ 0 0 0 ] );

%% shading 1
shading interp

%% erzeuge handle von light
lh = light;
set(lh,'Position', [0 0 20])
% UpdateLightPos( lh );

% LightColor
set(lh, 'Color', [1 1 1]);

    %% LightStyle; local
set(lh, 'Style','local' );
%% inf
set(lh, 'Style','infinite' );

%% setze renderer; opengl
set(fig_h,'Renderer','opengl')

%% setze renderer; zbuffer
set(fig_h,'Renderer','zbuffer')

%% shading 2
shading flat

%% shading 3
shading faceted

%% repos light
set(lh,'Position', [0 125 100000]);
UpdateLightPos( lh );

%% toggle light
set(lh, 'Visible', 'off');
%% toggle light
set(lh, 'Visible', 'on');

%% move light x
for i = 0:k:250
    set(lh,'Position', [ 0 i 500])
    UpdateLightPos( lh ); 

    pause(.5)  

end

%% getframe
F = getframe();
surf(double(F.cdata));

