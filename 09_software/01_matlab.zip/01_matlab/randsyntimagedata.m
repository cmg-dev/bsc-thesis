%% clear P, Pmax
clear('P','Pmap', 'i', 'k', ...
    'lh', 'lpos', 'X', 'Y' );
k = 10;
i = 0;
lpos = [ 0 0 0 ];
xlab = 'Width'; ylab = 'Height'; zlab = 'Grayscale';
tit ='Heightmap';
Y = 0;
X = 0;

surf(x,y,Z);
colorbar
colormap gray

% [X,Y,Z] = peaks(1000);
% light
% surfc(X,Y,Z)
% colormap gray
% axis([-3 3 -3 3 -10 5])
