function [ posx, posy, posz ] = UpdateLightPos( lh )
%UPDATELIGHTPOS Summary of this function goes here
%   Detailed explanation goes here
% lpos = [0 0 0];
lpos = get(lh, 'Position');
posx = lpos(1);
posy = lpos(2);
posz = lpos(3);

hold on 
scatter3( posx, posy, posz );
hold off

end

